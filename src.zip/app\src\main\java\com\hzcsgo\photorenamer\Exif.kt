package com.hzcsgo.photorenamer

import java.time.Instant
import java.time.LocalDateTime
import java.time.ZoneId
import java.time.ZoneOffset

/** 从 EXIF / MakerNote 里读出来的信息 */
data class Meta(
    val date: LocalDateTime? = null,
    val make: String = "",
    val model: String = "",
    val shutter: Long = -1L
)

data class Motion(val isMotion: Boolean, val reason: String)

object Exif {

    private fun u16(b: ByteArray, o: Int, le: Boolean): Int {
        if (o < 0 || o + 1 >= b.size) return 0
        return if (le) {
            (b[o].toInt() and 0xFF) or ((b[o + 1].toInt() and 0xFF) shl 8)
        } else {
            ((b[o].toInt() and 0xFF) shl 8) or (b[o + 1].toInt() and 0xFF)
        }
    }

    private fun u32(b: ByteArray, o: Int, le: Boolean): Long {
        if (o < 0 || o + 3 >= b.size) return 0
        return if (le) {
            (b[o].toLong() and 0xFF) or
                ((b[o + 1].toLong() and 0xFF) shl 8) or
                ((b[o + 2].toLong() and 0xFF) shl 16) or
                ((b[o + 3].toLong() and 0xFF) shl 24)
        } else {
            ((b[o].toLong() and 0xFF) shl 24) or
                ((b[o + 1].toLong() and 0xFF) shl 16) or
                ((b[o + 2].toLong() and 0xFF) shl 8) or
                (b[o + 3].toLong() and 0xFF)
        }
    }

    private fun ascii(b: ByteArray, o: Int, n: Int): String {
        if (o < 0 || n <= 0 || o + n > b.size) return ""
        val sb = StringBuilder()
        for (i in o until o + n) {
            val c = b[i].toInt() and 0xFF
            if (c == 0) break
            sb.append(c.toChar())
        }
        return sb.toString().trim()
    }

    /** TIFF 结构解析：JPEG 的 APP1 和 NEF/CR2 这类 RAW 都适用 */
    fun readTiff(b: ByteArray, tiff: Int): Meta {
        var make = ""
        var model = ""
        var dt = ""
        var shutter = -1L

        if (tiff < 0 || tiff + 8 > b.size) return Meta()
        val le = (b[tiff].toInt() and 0xFF) == 0x49
        val ifd0 = tiff + u32(b, tiff + 4, le).toInt()
        if (ifd0 <= 0 || ifd0 + 2 > b.size) return Meta()

        val n0 = u16(b, ifd0, le)
        var exifIfd = -1
        for (k in 0 until n0) {
            val e = ifd0 + 2 + k * 12
            if (e + 12 > b.size) break
            val tag = u16(b, e, le)
            val cnt = u32(b, e + 4, le).toInt()
            if (cnt <= 0 || cnt > 512) continue
            val voff = if (cnt <= 4) e + 8 else tiff + u32(b, e + 8, le).toInt()
            when (tag) {
                0x010F -> make = ascii(b, voff, cnt)
                0x0110 -> model = ascii(b, voff, cnt)
                0x0132 -> dt = ascii(b, voff, cnt)
                0x8769 -> exifIfd = tiff + u32(b, e + 8, le).toInt()
            }
        }

        var mn = -1
        if (exifIfd > 0 && exifIfd + 2 <= b.size) {
            val n1 = u16(b, exifIfd, le)
            for (k in 0 until n1) {
                val e = exifIfd + 2 + k * 12
                if (e + 12 > b.size) break
                val tag = u16(b, e, le)
                val cnt = u32(b, e + 4, le).toInt()
                if (tag == 0x927C) {
                    mn = tiff + u32(b, e + 8, le).toInt()
                } else if (tag == 0x9003 && cnt in 1..64) {
                    val voff = if (cnt <= 4) e + 8 else tiff + u32(b, e + 8, le).toInt()
                    val d2 = ascii(b, voff, cnt)
                    if (d2.isNotEmpty()) dt = d2
                }
            }
        }

        // Nikon MakerNote: 快门数
        if (mn > 0 && mn + 16 < b.size) {
            val mt = mn + 10
            if (mt + 8 < b.size) {
                val mle = (b[mt].toInt() and 0xFF) == 0x49
                val mifd = mt + u32(b, mt + 4, mle).toInt()
                if (mifd > 0 && mifd + 2 < b.size) {
                    val n = u16(b, mifd, mle)
                    if (n in 1..512) {
                        for (k in 0 until n) {
                            val e = mifd + 2 + k * 12
                            if (e + 12 > b.size) break
                            if (u16(b, e, mle) == 0x00A7) shutter = u32(b, e + 8, mle)
                        }
                    }
                }
            }
        }

        return Meta(parseDate(dt), make, model, shutter)
    }

    private fun parseDate(s0: String): LocalDateTime? {
        if (s0.isEmpty()) return null
        val s = s0.filter { it.isDigit() || it == ':' || it == ' ' }.trim()
        if (s.length < 19) return null
        return try {
            val y = s.substring(0, 4).toInt()
            val mo = s.substring(5, 7).toInt()
            val d = s.substring(8, 10).toInt()
            val h = s.substring(11, 13).toInt()
            val mi = s.substring(14, 16).toInt()
            val se = s.substring(17, 19).toInt()
            if (y in 1990..2100) LocalDateTime.of(y, mo, d, h, mi, se) else null
        } catch (e: Exception) {
            null
        }
    }

    /** JPEG：找到 APP1 Exif 段再解析 */
    fun readJpeg(b: ByteArray): Meta {
        var i = 2
        while (i < b.size - 3) {
            if ((b[i].toInt() and 0xFF) != 0xFF) break
            val m = b[i + 1].toInt() and 0xFF
            if (m == 0xFF) { i++; continue }
            if (m == 0xD8 || m == 0x01 || (m in 0xD0..0xD7)) { i += 2; continue }
            if (m == 0xD9 || m == 0xDA) break
            val len = ((b[i + 2].toInt() and 0xFF) shl 8) or (b[i + 3].toInt() and 0xFF)
            if (len < 2) break
            if (m == 0xE1 && len > 10 && i + 10 <= b.size) {
                val hdr = String(b, i + 4, 4, Charsets.ISO_8859_1)
                if (hdr == "Exif") return readTiff(b, i + 10)
            }
            i += 2 + len
        }
        return Meta()
    }

    /** JPEG 段扫描：判断是否动态照片（尾部追加 MP4 / 三星 SEF / XMP 标记） */
    fun motionInfo(b: ByteArray): Motion {
        var eoi = -1
        var i = 2
        while (i < b.size - 3) {
            if ((b[i].toInt() and 0xFF) != 0xFF) { i++; continue }
            val m = b[i + 1].toInt() and 0xFF
            if (m == 0xFF) { i++; continue }
            if (m == 0x00) { i += 2; continue }
            if (m == 0xD8 || m == 0x01 || (m in 0xD0..0xD7)) { i += 2; continue }
            if (m == 0xD9) { eoi = i; break }
            val len = ((b[i + 2].toInt() and 0xFF) shl 8) or (b[i + 3].toInt() and 0xFF)
            if (len < 2 || i + 2 + len > b.size) break
            if (m == 0xDA) {
                var j = i + 2 + len
                while (j < b.size - 1) {
                    if ((b[j].toInt() and 0xFF) == 0xFF) {
                        val nx = b[j + 1].toInt() and 0xFF
                        if (nx == 0x00 || (nx in 0xD0..0xD7)) { j += 2; continue }
                        break
                    }
                    j++
                }
                i = j
                continue
            }
            i += 2 + len
        }
        if (eoi < 0) return Motion(false, "")
        val trail = b.size - (eoi + 2)
        if (trail > 8) {
            val t = String(b, eoi + 2, minOf(12, trail), Charsets.ISO_8859_1)
            if (t.length >= 8 && t.substring(4, 8) == "ftyp") return Motion(true, "JPEG 尾部追加 MP4")
            if (trail > 1024) {
                val tail = String(b, eoi + 2, minOf(trail, 65536), Charsets.ISO_8859_1)
                if (tail.contains("SEFH")) return Motion(true, "三星 SEF 尾块")
            }
        }
        val scan = minOf(b.size, 300000)
        val head = String(b, 0, scan, Charsets.ISO_8859_1)
        if (head.contains("MotionPhoto") || head.contains("MicroVideo")) {
            return Motion(true, "XMP 动态照片标记")
        }
        return Motion(false, "")
    }

    /** 动图：GIF 多帧 / WebP ANIM / PNG acTL */
    fun isAnimated(b: ByteArray, ext: String): Boolean {
        return when (ext) {
            "gif" -> {
                var n = 0
                for (i in 0 until b.size - 1) {
                    if ((b[i].toInt() and 0xFF) == 0x21 && (b[i + 1].toInt() and 0xFF) == 0xF9) n++
                }
                n >= 2
            }
            "webp" -> String(b, 0, minOf(b.size, 262144), Charsets.ISO_8859_1).contains("ANIM")
            "png" -> String(b, 0, minOf(b.size, 262144), Charsets.ISO_8859_1).contains("acTL")
            else -> false
        }
    }

    /** 视频：读 mvhd 的创建时间 */
    fun videoDate(b: ByteArray): LocalDateTime? {
        val s = String(b, 0, b.size, Charsets.ISO_8859_1)
        val i = s.indexOf("mvhd")
        if (i < 0 || i + 32 >= b.size) return null
        val ver = b[i + 4].toInt() and 0xFF
        var sec: Long
        if (ver == 1) {
            sec = 0
            for (k in 0 until 8) {
                sec = (sec shl 8) or (b[i + 8 + k].toLong() and 0xFF)
            }
        } else {
            sec = u32(b, i + 8, false)
        }
        if (sec <= 0) return null
        val epoch = LocalDateTime.of(1904, 1, 1, 0, 0, 0).toInstant(ZoneOffset.UTC)
        val dt = LocalDateTime.ofInstant(epoch.plusSeconds(sec), ZoneId.systemDefault())
        return if (dt.year in 1990..2100) dt else null
    }

    /** 相机型号清洗：NIKON Z5_2 -> Z52 */
    fun modelTag(make: String, model: String): String {
        var m = model.trim()
        if (m.isEmpty()) return ""

        val makers = arrayOf(
            "NIKON CORPORATION", "NIKON", "CANON", "SONY", "FUJIFILM", "OLYMPUS",
            "PENTAX", "RICOH", "PANASONIC", "LEICA", "SAMSUNG", "APPLE", "XIAOMI",
            "HUAWEI", "HONOR", "OPPO", "VIVO", "GOOGLE", "MOTOROLA", "ONEPLUS",
            "REALME", "ASUS", "LENOVO", "REDMI", "MEIZU"
        )
        val upper = m.uppercase()
        for (mk in makers) {
            if (upper.startsWith(mk)) {
                m = m.substring(mk.length)
                break
            }
        }
        m = m.replace(Regex("[^A-Za-z0-9]"), "")
        if (m.length > 14) m = m.substring(0, 14)
        return m
    }

    /** 文件名末尾的数字，DSC_6463 -> 6463 */
    fun seqFromName(name: String): String {
        val base = name.substringBeforeLast('.', name)
        val m = Regex("(\\d+)$").find(base) ?: return ""
        return if (m.value.length <= 6) m.value else ""
    }

    /** 文件名里的日期：微信图片_20261116125047 -> 2026-11-16 12:50:47 */
    fun dateFromName(name: String): LocalDateTime? {
        val base = name.substringBeforeLast('.', name)
        Regex("(20\\d{2})[-_.]?(\\d{2})[-_.]?(\\d{2})[-_.]?(\\d{2})(\\d{2})(\\d{2})").find(base)?.let {
            return try {
                LocalDateTime.of(
                    it.groupValues[1].toInt(), it.groupValues[2].toInt(), it.groupValues[3].toInt(),
                    it.groupValues[4].toInt(), it.groupValues[5].toInt(), it.groupValues[6].toInt()
                )
            } catch (e: Exception) { null }
        }
        Regex("(20\\d{2})[-_.]?(\\d{2})[-_.]?(\\d{2})").find(base)?.let {
            return try {
                LocalDateTime.of(
                    it.groupValues[1].toInt(), it.groupValues[2].toInt(), it.groupValues[3].toInt(), 0, 0, 0
                )
            } catch (e: Exception) { null }
        }
        return null
    }

    fun fromMillis(ms: Long): LocalDateTime =
        LocalDateTime.ofInstant(Instant.ofEpochMilli(ms), ZoneId.systemDefault())
}
