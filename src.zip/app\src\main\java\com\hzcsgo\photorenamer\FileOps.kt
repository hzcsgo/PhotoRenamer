package com.hzcsgo.photorenamer

import android.content.Context
import android.net.Uri
import androidx.documentfile.provider.DocumentFile
import java.io.ByteArrayOutputStream

object Kinds {
    val IMAGE = setOf("jpg", "jpeg", "jfif", "png", "gif", "webp", "bmp", "heic", "heif", "avif")
    val RAW = setOf("nef", "nrw", "cr2", "cr3", "arw", "sr2", "dng", "orf", "rw2", "raf", "tif", "tiff", "pef", "srw")
    val VIDEO = setOf("mp4", "mov", "m4v", "avi", "mkv", "wmv", "3gp", "mpg", "mpeg")

    fun extOf(name: String): String = name.substringAfterLast('.', "").lowercase()
    fun isJpeg(e: String) = e == "jpg" || e == "jpeg" || e == "jfif"
    fun isRaw(e: String) = e in RAW
    fun isVideo(e: String) = e in VIDEO
    fun isImage(e: String) = e in IMAGE || e in RAW

    fun mimeOf(name: String): String = when (extOf(name)) {
        "jpg", "jpeg", "jfif" -> "image/jpeg"
        "png" -> "image/png"
        "gif" -> "image/gif"
        "webp" -> "image/webp"
        "heic", "heif" -> "image/heic"
        "avif" -> "image/avif"
        "mp4", "m4v" -> "video/mp4"
        "mov" -> "video/quicktime"
        else -> "application/octet-stream"
    }
}

class FileOps(private val ctx: Context) {

    /** 只列当层文件 */
    fun children(dir: DocumentFile): List<DocumentFile> {
        val arr = dir.listFiles()
        return arr.filter { it.isFile }
    }

    /** 递归列文件，深度和总数都有上限，防止卡死 */
    fun tree(root: DocumentFile, maxDepth: Int = 5, limit: Int = 20000): List<DocumentFile> {
        val out = ArrayList<DocumentFile>()
        fun walk(d: DocumentFile, depth: Int) {
            if (depth > maxDepth || out.size >= limit) return
            val kids = try { d.listFiles() } catch (e: Exception) { emptyArray<DocumentFile>() }
            for (k in kids) {
                if (out.size >= limit) return
                if (k.isDirectory) walk(k, depth + 1) else out.add(k)
            }
        }
        walk(root, 0)
        return out
    }

    /** 只读前 max 字节，读不到就返回已读到的部分 */
    fun readBytes(uri: Uri, max: Int): ByteArray {
        return try {
            ctx.contentResolver.openInputStream(uri)?.use { input ->
                val bos = ByteArrayOutputStream()
                val buf = ByteArray(128 * 1024)
                var total = 0
                while (total < max) {
                    val n = input.read(buf, 0, minOf(buf.size, max - total))
                    if (n <= 0) break
                    bos.write(buf, 0, n)
                    total += n
                }
                bos.toByteArray()
            } ?: ByteArray(0)
        } catch (e: Exception) {
            ByteArray(0)
        }
    }

    fun exists(dir: DocumentFile, name: String): Boolean =
        try { dir.findFile(name) != null } catch (e: Exception) { false }

    fun copy(src: Uri, dstDir: DocumentFile, name: String): Boolean {
        return try {
            val doc = dstDir.createFile(Kinds.mimeOf(name), name) ?: return false
            ctx.contentResolver.openInputStream(src)?.use { input ->
                ctx.contentResolver.openOutputStream(doc.uri)?.use { out ->
                    input.copyTo(out, 256 * 1024)
                }
            }
            true
        } catch (e: Exception) {
            false
        }
    }
}
