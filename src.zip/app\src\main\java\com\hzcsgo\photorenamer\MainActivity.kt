package com.hzcsgo.photorenamer

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.widget.Button
import android.widget.CheckBox
import android.widget.ScrollView
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.documentfile.provider.DocumentFile
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter
import java.util.concurrent.Executors

class MainActivity : AppCompatActivity() {

    private lateinit var logView: TextView
    private lateinit var scroll: ScrollView
    private lateinit var previewBox: CheckBox
    private lateinit var ops: FileOps

    private val io = Executors.newSingleThreadExecutor()
    private val ui = Handler(Looper.getMainLooper())

    private var mode = 0
    private var step = 0
    private var uriA: Uri? = null
    private var previewOnly = false

    private data class Item(
        val src: DocumentFile,
        val name: String,
        val info: String,
        val raw: DocumentFile? = null
    )

    private val picker = registerForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri ->
        onPicked(uri)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        ops = FileOps(this)
        logView = findViewById(R.id.log)
        scroll = findViewById(R.id.scroll)
        previewBox = findViewById(R.id.preview)

        findViewById<Button>(R.id.btn1).setOnClickListener { start(1) }
        findViewById<Button>(R.id.btn2).setOnClickListener { start(2) }
        findViewById<Button>(R.id.btn3).setOnClickListener { start(3) }
        findViewById<Button>(R.id.btnClear).setOnClickListener { logView.text = "" }

        log("点上面按钮选择文件夹，先出清单，确认后才写入。")
        log("原文件不会改动，结果复制到新文件夹里。")
    }

    // ---------------- 流程 ----------------

    private fun start(m: Int) {
        if (step != 0) {
            log("正在处理，请稍等")
            return
        }
        mode = m
        step = 1
        uriA = null
        previewOnly = previewBox.isChecked
        picker.launch(null)
    }

    private fun onPicked(uri: Uri?) {
        if (uri == null) {
            log("已取消选择")
            step = 0
            return
        }
        try {
            contentResolver.takePersistableUriPermission(
                uri,
                Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION
            )
        } catch (e: Exception) {
            // 有些系统只给读权限，忽略
        }

        val doc = DocumentFile.fromTreeUri(this, uri)
        if (doc == null) {
            log("无法访问这个文件夹")
            step = 0
            return
        }

        if (step == 1) {
            uriA = uri
            when (mode) {
                2 -> {
                    step = 2
                    log("请再选一个放着 RAW 的文件夹")
                    picker.launch(null)
                }
                3 -> {
                    step = 2
                    io.execute {
                        val hasRaw = ops.tree(doc).any { Kinds.isRaw(Kinds.extOf(it.name ?: "")) }
                        ui.post {
                            if (hasRaw) {
                                runPlan(3, uriA!!, uri)
                            } else {
                                log("这个文件夹里没找到 RAW，请再选一个 RAW 文件夹")
                                picker.launch(null)
                            }
                        }
                    }
                }
                else -> runPlan(1, uri, uri)
            }
        } else {
            runPlan(mode, uriA!!, uri)
        }
    }

    private fun runPlan(m: Int, aUri: Uri, bUri: Uri) {
        val a = DocumentFile.fromTreeUri(this, aUri)
        val b = DocumentFile.fromTreeUri(this, bUri)
        if (a == null || b == null) {
            log("无法访问文件夹")
            step = 0
            return
        }
        log("=== 开始扫描 ===")
        io.execute {
            try {
                val t0 = System.currentTimeMillis()
                when (m) {
                    1 -> planMode1(a)
                    2 -> planMode2(a, b)
                    3 -> planMode3(a, b)
                }
                log("扫描耗时 " + (System.currentTimeMillis() - t0) / 1000 + " 秒")
            } catch (e: Exception) {
                log("出错：" + (e.message ?: e.toString()))
            }
            step = 0
        }
    }

    // ---------------- 功能 1：批量改名 ----------------

    private fun planMode1(root: DocumentFile) {
        val files = ops.children(root)
        val items = ArrayList<Item>()
        val used = HashSet<String>()
        var n = 0

        for (f in files) {
            n++
            val name = f.name ?: continue
            val ext = Kinds.extOf(name)
            if (!Kinds.isImage(ext) && !Kinds.isVideo(ext)) continue
            if (n % 20 == 0) log("扫描 $n/${files.size}")

            var kind = "IMG"
            var info = ""
            var meta = Meta()
            var dt: LocalDateTime? = null

            if (Kinds.isVideo(ext)) {
                kind = "VID"
                meta = Meta(date = Exif.videoDate(ops.readBytes(f.uri, 2 shl 20)))
                dt = meta.date
            } else if (Kinds.isRaw(ext)) {
                meta = Exif.readTiff(ops.readBytes(f.uri, 3 shl 20), 0)
                dt = meta.date
            } else if (Kinds.isJpeg(ext)) {
                val bytes = ops.readBytes(f.uri, 40 shl 20)
                meta = Exif.readJpeg(bytes)
                dt = meta.date
                val mo = Exif.motionInfo(bytes)
                if (mo.isMotion) {
                    kind = "MVIMG"
                    info = mo.reason
                }
            } else if (ext == "gif" || ext == "webp" || ext == "png") {
                val bytes = ops.readBytes(f.uri, 40 shl 20)
                if (Exif.isAnimated(bytes, ext)) {
                    kind = "MVIMG"
                    info = "多帧"
                }
            }

            if (dt == null) dt = Exif.dateFromName(name)
            if (dt == null) dt = Exif.fromMillis(f.lastModified())
            val d = dt!!

            val isCamera = name.length > 3 && name.substring(0, 3).equals("DSC", true) &&
                (name[3] == '_' || name[3] == '-')
            val model = Exif.modelTag(meta.make, meta.model)
            val parts = ArrayList<String>()

            if (isCamera) {
                parts.add("DSC")
                if (model.isNotEmpty()) parts.add(model)
                parts.add(fmt(d, "yyyyMMdd"))
                val seq = Exif.seqFromName(name)
                if (seq.isNotEmpty()) parts.add(seq)
            } else {
                parts.add(kind)
                parts.add(fmt(d, "yyyyMMdd_HHmmss"))
            }

            val base = parts.joinToString("_")
            var newName = "$base.$ext"
            var k = 2
            while (used.contains(newName)) {
                newName = "${base}_$k.$ext"
                k++
            }
            used.add(newName)
            items.add(Item(f, newName, "$kind $info"))
        }

        log("共 ${items.size} 个文件")
        items.take(15).forEach { log("  ${it.src.name}  ->  ${it.name}") }
        if (items.isEmpty()) return
        if (previewOnly) {
            log("预览模式：没有写入任何文件")
            return
        }
        confirmAndRun(items, fmt(LocalDateTime.now(), "yyyyMMdd"), false)
    }

    // ---------------- 功能 2：找同名 RAW ----------------

    private fun planMode2(a: DocumentFile, b: DocumentFile) {
        log("扫描 RAW 文件夹...")
        val raws = ops.tree(b).filter { Kinds.isRaw(Kinds.extOf(it.name ?: "")) }
        log("找到 ${raws.size} 个 RAW")
        if (raws.isEmpty()) return

        val map = HashMap<String, MutableList<DocumentFile>>()
        for (r in raws) {
            val key = (r.name ?: "").substringBeforeLast('.').lowercase()
            map.getOrPut(key) { ArrayList() }.add(r)
        }

        val jpgs = ops.children(a).filter { Kinds.isJpeg(Kinds.extOf(it.name ?: "")) }
        val items = ArrayList<Item>()
        var miss = 0

        for (j in jpgs) {
            val key = (j.name ?: "").substringBeforeLast('.').lowercase()
            val hit = map[key]
            if (hit == null) {
                miss++
                continue
            }
            for (r in hit) items.add(Item(j, r.name ?: "raw", "同名", r))
        }

        log("匹配上 ${items.size} 张，没找到 RAW 的 $miss 张")
        items.take(15).forEach { log("  ${it.src.name}  ->  ${it.raw?.name}") }
        if (items.isEmpty()) return
        if (previewOnly) {
            log("预览模式：没有写入任何文件")
            return
        }
        confirmAndRun(items, "RAW", false)
    }

    // ---------------- 功能 3：用 RAW 匹配改名 ----------------

    private fun planMode3(a: DocumentFile, b: DocumentFile) {
        log("扫描 RAW...")
        val raws = ArrayList<DocumentFile>()
        raws.addAll(ops.tree(a).filter { Kinds.isRaw(Kinds.extOf(it.name ?: "")) })
        if (b.uri != a.uri) {
            raws.addAll(ops.tree(b).filter { Kinds.isRaw(Kinds.extOf(it.name ?: "")) })
        }
        log("RAW 共 ${raws.size} 个")
        if (raws.isEmpty()) return

        val byShutter = HashMap<Long, Pair<DocumentFile, Meta>>()
        var noShutter = 0
        var i = 0
        for (r in raws) {
            i++
            if (i % 20 == 0) log("读 RAW $i/${raws.size}")
            val m = Exif.readTiff(ops.readBytes(r.uri, 3 shl 20), 0)
            if (m.shutter <= 0) {
                noShutter++
                continue
            }
            if (!byShutter.containsKey(m.shutter)) byShutter[m.shutter] = Pair(r, m)
        }
        log("有快门数的 ${byShutter.size} 个，另外 $noShutter 个读不到快门数")
        if (byShutter.isEmpty()) return

        val jpgs = ops.children(a).filter { Kinds.isJpeg(Kinds.extOf(it.name ?: "")) }
        val items = ArrayList<Item>()
        val used = HashSet<String>()
        var miss = 0

        for (j in jpgs) {
            val jname = j.name ?: continue
            val bytes = ops.readBytes(j.uri, 40 shl 20)
            val jm = Exif.readJpeg(bytes)
            if (jm.shutter <= 0) {
                miss++
                continue
            }
            val hit = byShutter[jm.shutter]
            if (hit == null) {
                miss++
                continue
            }
            val r = hit.first
            val rm = hit.second

            val model = Exif.modelTag(rm.make, rm.model)
            var dt: LocalDateTime? = rm.date
            if (dt == null) dt = jm.date
            if (dt == null) dt = Exif.dateFromName(jname)
            if (dt == null) dt = Exif.fromMillis(j.lastModified())
            val d = dt!!

            val seq = Exif.seqFromName(r.name ?: "")
            val parts = ArrayList<String>()
            parts.add("DSC")
            if (model.isNotEmpty()) parts.add(model)
            parts.add(fmt(d, "yyyyMMdd"))
            if (seq.isNotEmpty()) parts.add(seq)

            val base = parts.joinToString("_")
            val ext = Kinds.extOf(jname)
            var newName = "$base.$ext"
            var k = 2
            while (used.contains(newName)) {
                newName = "${base}_$k.$ext"
                k++
            }
            used.add(newName)
            items.add(Item(j, newName, "快门 ${jm.shutter}", r))
        }

        log("匹配上 ${items.size} 张，没匹配到 $miss 张")
        items.take(15).forEach { log("  ${it.src.name}  ->  ${it.name}   (${it.raw?.name})") }
        if (items.isEmpty()) return
        if (previewOnly) {
            log("预览模式：没有写入任何文件")
            return
        }
        confirmAndRun(items, fmt(LocalDateTime.now(), "yyyyMMdd"), true)
    }

    // ---------------- 写入 ----------------

    private fun confirmAndRun(items: List<Item>, destName: String, rawSub: Boolean) {
        ui.post {
            AlertDialog.Builder(this)
                .setTitle("确认写入")
                .setMessage("将写入 ${items.size} 个文件到「$destName」，继续？")
                .setPositiveButton("开始") { _, _ -> execute(items, destName, rawSub) }
                .setNegativeButton("取消") { _, _ -> log("已取消") }
                .show()
        }
    }

    private fun execute(items: List<Item>, destName: String, rawSub: Boolean) {
        val root = DocumentFile.fromTreeUri(this, uriA ?: return) ?: return
        io.execute {
            val dest = root.findFile(destName) ?: root.createDirectory(destName)
            if (dest == null) {
                log("无法创建输出文件夹")
                return@execute
            }
            val rawDir = if (rawSub) (dest.findFile("RAW") ?: dest.createDirectory("RAW")) else null

            var ok = 0
            var fail = 0
            var i = 0
            for (it in items) {
                i++
                val dstName = uniqueName(dest, it.name)
                if (ops.copy(it.src.uri, dest, dstName)) {
                    ok++
                    val r = it.raw
                    if (r != null && rawDir != null) {
                        val rn = r.name ?: "raw"
                        if (!ops.exists(rawDir, rn)) ops.copy(r.uri, rawDir, rn)
                    }
                } else {
                    fail++
                }
                if (i % 10 == 0 || i == items.size) log("写入 $i/${items.size}")
            }
            log("完成：成功 $ok 个，失败 $fail 个")
            log("输出在「$destName」" + (if (rawSub) "，RAW 在里面的 RAW 子文件夹" else ""))
        }
    }

    private fun uniqueName(dir: DocumentFile, name: String): String {
        if (!ops.exists(dir, name)) return name
        val base = name.substringBeforeLast('.', name)
        val ext = name.substringAfterLast('.', "")
        var k = 2
        while (true) {
            val cand = if (ext.isEmpty()) "${base}_$k" else "${base}_$k.$ext"
            if (!ops.exists(dir, cand)) return cand
            k++
            if (k > 9999) return cand
        }
    }

    // ---------------- 小工具 ----------------

    private fun fmt(dt: LocalDateTime, pattern: String): String =
        dt.format(DateTimeFormatter.ofPattern(pattern))

    private fun log(s: String) {
        ui.post {
            logView.append(s + "\n")
            scroll.post { scroll.fullScroll(android.view.View.FOCUS_DOWN) }
        }
    }
}
