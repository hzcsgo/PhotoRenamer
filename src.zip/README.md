# 照片改名（安卓版）

把电脑上那个 `照片整理改名.bat` 的三套功能搬到手机上，界面很朴素，能用就行。

- 功能① 批量改名：`IMG_时间` / `MVIMG_时间`（动态照片、动图）/ `VID_时间`，相机原片用 `DSC_型号_日期_序号`
- 功能② 按同名找 RAW：选两个文件夹，把同名的 RAW 收进 `<照片文件夹>\RAW`
- 功能③ 用 RAW 匹配改名：用**快门数**把被抹掉 EXIF 的 JPG 和 RAW 配对，型号/日期/序号全部取自 RAW，RAW 收进 `<照片文件夹>\<日期>\RAW`

原文件永远不改、不删，结果都是复制到新文件夹。

## 环境

- Android 8.0 以上（小米 14 / Android 16 没问题）
- 编译：Android Gradle Plugin 8.5.2 + Kotlin 1.9.24 + JDK 17

## 打包（GitHub Actions，不用装 Android Studio）

1. 在 GitHub 新建一个空仓库，名字随意，比如 `PhotoRenamer`（不要勾选 README）
2. 打开仓库页面 → **Add file → Upload files** → 把本文件夹里的**所有内容**（包括 `.github` 目录）拖进去 → Commit
3. 点仓库上方的 **Actions** → 左边 `build-apk` → 右边 **Run workflow**（如果刚才的 commit 已经自动跑过，就直接看最新那次）
4. 等 2～4 分钟变绿

5. 下载 APK，两种任选：

   **直接链接（推荐，手机也能直接点）**

   ```
   https://github.com/hzcsgo/PhotoRenamer/releases/latest/download/app-debug.apk
   ```

   不用登录、不用解压，点开就是 APK。

   或者进那次运行，页面底部 **Artifacts** 下载 `app-debug.zip` 再解压。

安装时小米会拦：

- 设置 → 应用设置 → 应用管理 → 右上角「…」→ 特殊权限 → 安装未知应用 → 允许你的浏览器/文件管理器
- 安装界面出现「应用未经安全检测」时选「继续安装」

## 或者用命令行上传

```bash
cd PhotoRenamer
git init
git add .
git commit -m "first"
git branch -M main
git remote add origin https://github.com/hzcsgo/PhotoRenamer.git
git push -u origin main
```

注意：GitHub 推送不能用登录密码，要 Personal Access Token。
Settings → Developer settings → Personal access tokens → Tokens (classic) → Generate new token，
勾选 `repo`，生成后把它当成密码粘贴。

## 用起来是怎样的

1. 打开 App，点对应功能的按钮
2. 系统弹出文件夹选择器（这是安卓的规矩：App 不能直接读写路径，必须你点选授权）
3. 先出清单（前 15 条），点「开始」才真正写入
4. 勾上「只预览，不写入」就只看结果不落盘

输出位置：

- 功能①：`<你选的文件夹>\当天日期\`
- 功能②：`<照片文件夹>\RAW\`
- 功能③：`<照片文件夹>\当天日期\`，RAW 在里面的 `RAW\` 子文件夹

## 已知限制

- 只处理**当层**文件，不进子文件夹（避免把输出目录又扫一遍）
- 功能②、③的 RAW 索引会递归 5 层
- 判断动态照片要读整个 JPEG（15～25MB），大文件夹会慢一点，但扫描时是顺序读，UFS 4.0 上几百张也就十几秒
- 快门数只认尼康的 MakerNote；其他品牌功能③会显示「读不到快门数」
- APK 是 debug 签名，自己用没问题，不能上应用商店

## 文件结构

```
app/src/main/java/com/hzcsgo/photorenamer/
  MainActivity.kt   界面和三个功能
  Exif.kt           EXIF / Nikon MakerNote / 动态照片 / 动图 / mvhd 解析
  FileOps.kt        SAF 文件操作（读、复制、建目录）
```
